#include <algorithm>

#include "tridiag.hpp"

namespace td {
  namespace doublesweep {
    template<typename V>
      void twodiagonalize(tridiag<V>& t, std::vector<V>& d);
    template<typename V>
      void sweepback(tridiag<V>& t, std::vector<V>& d);
    template<typename V>
      void solve(tridiag<V>& t, std::vector<V>& d);
    template<typename V>
      void relax(tridiag<V>& t, std::vector<V>& d, int i1, int i2);
    template<typename V>
      void relax_forward(tridiag<V>& t, std::vector<V>& d, int i1, int i2);
    template<typename V>
      void relax_backward(tridiag<V>& t, std::vector<V>& d, int i1, int i2);

    template<typename V>
      void twodiagonalize(tridiag<V>& t, std::vector<V>& d) { // particular case
        int n = t.size();
        if (t(0,0) != 0) t.mul_row(0, 1/t(0,0));
        for (int i = 1; i < n; ++i) {
          if (t(i-1,i-1) != 0) {
            relax_forward(t, d, i-1, i);
          }
          if (t(i,i) != 0) {
            d[i] /= t(i,i);
            t.mul_row(i, 1/t(i,i));
          }
        }
      }

    template<typename V>
      void sweepback(tridiag<V>& t, std::vector<V>& d) {
        int n = t.size();
        int base;
        for (base = 0; base < n; ++base)
          if (t.row_vars_no(base) == 1) break;
        if (base == n)
          throw "fixme";
        --n;
        for (int i = base; i < n - 1; ++i)
          relax_forward(t, d, i, i+1);
        for (int i = base; i >= 0; --i)
          relax_backward(t, d, i, i+1);
      }

    template<typename V>
      void solve(tridiag<V>& t, std::vector<V>& d) {
        std::cout << t;
        size_t n = d.size();
        twodiagonalize(t, d);
        // for_each(d.begin(), d.end(), [](V v) { std::cout << "v=" << v << std::endl; });
        sweepback(t, d);
        // if the input is trivial, we're happy
        //
        // but it can happen
        // that there were zeroes on main diagonal
        // which resulted in inability
        // to cancel interfering variables
        // in trivial way 
        // (i.e. by reducing coefficients only
        //  in adjacent rows
        //  and only in a single direction)
        if (!t.diagonalized()) {
          for (int i = 0; i < n - 1; ++i)
            relax(t, d, i, i+1);
        }
        for (int i = 0; i < n; ++i) {
          if (t(i,i) != 0) {
            d[i] /= t(i,i);
            t.mul_row(i, 1/t(i,i));
          }
        }
        std::cout << t;
      }

    template<typename V>
      void relax(tridiag<V>& t, std::vector<V>& d, int i1, int i2) {
        if (i1 == i2) return;
        if (i1 > i2) {
          int t = i1;
          i1 = i2;
          i2 = i1;
        }
        relax_forward(t, d, i1, i2);
        relax_backward(t, d, i1, i2);
      }

    template<typename V>
      void relax_forward(tridiag<V>& t, std::vector<V>& d, int i1, int i2) {
        assert(i1 < i2);
        if (t(i2, i2-1) != 0) {
          if (t(i1, i1) != 0) {
            double alpha = -t(i2,i2-1)/t(i1,i1);
            std::cout << "f " << i1 << " " << i2 << " " << alpha << std::endl;
//            std::cout << alpha << " " << t(i1, i1) << " " << t(i2, i2-1) << std::endl;
            t.row_add(i1, i2, alpha);
            d[i2] += alpha*d[i1];
            std::cout << t;
          }
        }
      }

    template<typename V>
      void relax_backward(tridiag<V>& t, std::vector<V>& d, int i1, int i2) {
        assert(i1 < i2);
        if (t(i1, i1+1) != 0) {
          if (t(i2,i2) != 0) {
            double alpha = -t(i1,i1+1)/t(i2, i2);
            std::cout << "b " << i1 << " " << i2 << " " << alpha << std::endl;
            t.row_add(i2, i1, alpha);
            d[i1] += alpha*d[i2];
            std::cout << t;
          }
        }
      }
  }
}
