#ifndef TRIDIAG_EXT
#define TRIDIAG_EXT

#include <vector>
#include <algorithm>
#include <istream>
#include <stdexcept>
#include <cassert>

using std::istream;
using std::ostream;
using std::fill_n;
using std::for_each;
using std::out_of_range;

namespace td {
  template<typename V>
    class tridiag_ext {
      public:
        typedef std::vector<V> vector;
        typedef vector& vec_ref;
        typedef const vector& vec_const_ref;
        typedef V& val_ref;
        typedef const V& val_const_ref;

        tridiag_ext(int N);
        tridiag_ext(vector sup, vector main, vector sub, vector d);
        tridiag_ext(istream td_in, istream d_in);

        val_const_ref operator()(int i, int j) const;
        val_ref operator()(int i, int j);
        void mul_row(int i, V alpha);
        void row_add(int from, int to, V alpha);
        size_t size();
        size_t row_vars_no(int row) const;
        ostream& operator<<(ostream& o);
      private:
        int N;
        tridiag<V> A;
        vector <V> d;
    }
}

#define TD_T_DEC template<typename V>
#define TD_C_DEC td::tridiag_ext<V>
#define TD_C typename TD_C_DEC
TD_T_DEC
explicit TD_C_DEC::tridiag_ext(int n) : N(n){
  A = tridiag<V>(n);
  d.resize(n);
}

TD_T_DEC
explicit TD_C_DEC::tridiag_ext(vector sup, vector main, vector sub, vector d) {
  A = tridiag<V>(sup,main,sub);
  this->d = d;
  N = A.size();
}

TD_T_DEC
explicit TD_C_DEC::tridiag_ext(istream td_in, istream d_in) {
  A = tridiag<V>(td_in);
  N = A.size();
  int n1;
  d_in >> n1;
  assert(N == n1);
  d.reserve(n1);
  for (int i = 0; i < N; ++i) {
    double v;
    d_in >> v;
    d.push_back(v);
  }
}

TD_T_DEC
TD_C::val_ref TD_C_DEC::operator()(int i, int j) {
  if (j == N && i > 0 && i < N) return d[i];
  return A(i,j);
}

TD_T_DEC
TD_C::val_const_ref TD_C_DEC::operator()(int i, int j) const {
  if (j == N && i > 0 && i < N) return d[i];
  return A(i,j);
}

TD_T_DEC
void TD_C_DEC::mul_row(int i, V alpha) {
  A.mul_row(i, alpha);
  d[i] *= alpha;
}

TD_T_DEC
void TD_C_DEC::row_add(int from, int to, V alpha) {
  A.row_add(i, alpha);
  d[to] += alpha * d[from];
}

TD_T_DEC
size_t TD_C_DEC::row_vars_no(int row) const {
  return A.row_vars_no(row);
}

TD_T_DEC
ostream& operator<<(ostream& out) {
  out << "$$\\begin{pmatrix}" << std::endl;
  for (int i = 0; i < N; ++i) {
    for (int j = 0; j < N; ++j) {
      out << (*this)(i, j);
      if (j != N -1)
        out << " & ";
    }

    out << " \\vline "  << (*this)(i, N);
    if (i !=  N -1)
      out << " \\\\";
    out << std::endl;
  }
  out << "\\end{pmatrix}$$" << std::endl;
  return out;
}

#undef TD_c
#undef TD_C_DEC
#undef TD_T_DEC
#endif
