#ifndef TD_DOUBLESWEEP
#define TD_DOUBLESWEEP

#include <iostream>
#include <fstream>

#include "tridiag.hpp"
#include "doublesweep.cpp"

using namespace td;
using namespace doublesweep;

int main(int argc, char** argv) {
  std::cout.precision(8);
  std::cout.setf(std::ios::fixed);
  int n;
  std::string td_fname(argv[1]), d_fname(argv[2]);
  std::ifstream td_in(td_fname);
  tridiag<double> t(td_in);
  n = t.size();
  std::vector<double> d;
  d.reserve(n);
  std::ifstream d_in(d_fname);
  solve(t, d);
  std::cout << "$$\\begin{pmatrix}" << std::endl;
  for(int i = 0; i < n; ++i) {
    std::cout << d[i];
    if (i != n-1) std::cout << " \\\\";
    std::cout << std::endl;
  }
  std::cout << "\\end{pmatrix}$$" << std::endl;
  return 0;
}

#endif
